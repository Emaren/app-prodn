const chokidar = require('chokidar');
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');
const FormData = require('form-data');

function getDefaultReplayDir() {
  const home = os.homedir();
  const platform = os.platform();

  if (platform === 'darwin') {
    // macOS with Crossover
    return path.join(
      home,
      'Library/Application Support/CrossOver/Bottles/Steam/drive_c/Program Files (x86)/Steam/steamapps/common/Age2HD/SaveGame'
    );
  } else if (platform === 'win32') {
    // Windows default path
    return path.join(home, 'Documents', 'My Games', 'Age of Empires 2 HD', 'SaveGame');
  } else {
    // Linux (e.g., Wine or Proton setups)
    return path.join(home, '.wine/drive_c/Program Files (x86)/Microsoft Games/Age of Empires II HD/SaveGame');
  }
}

const WATCH_DIR = getDefaultReplayDir();
let latestUploaded = '';

exports.startWatching = () => {
  console.log(`🔍 Watching directory: ${WATCH_DIR}`);

  const watcher = chokidar.watch(WATCH_DIR, {
    persistent: true,
    ignoreInitial: false,
    depth: 0,
    awaitWriteFinish: {
      stabilityThreshold: 1500,
      pollInterval: 100,
    },
  });

  watcher.on('add', onFileDetected);
  watcher.on('change', onFileDetected);
};

async function onFileDetected(filePath) {
  if (!filePath.endsWith('.aoe2record')) return;
  if (filePath === latestUploaded) return;

  latestUploaded = filePath;
  console.log('📤 Uploading:', filePath);

  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));

  try {
    const res = await axios.post('http://localhost:8002/api/upload_replay', form, {
      headers: form.getHeaders(),
    });
    console.log('✅ Uploaded:', res.status);
  } catch (err) {
    console.error('❌ Upload failed:', err.message);
    if (err.response) {
      console.error('❌ Server response:', err.response.status, err.response.data);
    }
  }
}
