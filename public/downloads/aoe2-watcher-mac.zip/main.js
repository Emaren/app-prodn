const { app } = require('electron');
const path = require('path');
const watcher = require('./watcher');

app.whenReady().then(() => {
  watcher.startWatching();
});
